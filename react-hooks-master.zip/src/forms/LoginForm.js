import React, { useState } from 'react'
import { useHistory } from "react-router-dom";
import { InputText } from "primereact/inputtext";

const LoginForm = props => {
	const initialFormState = { username: '', password: '' }
	const [user, setUser] = useState(initialFormState)

	const handleInputChange = event => {
		const { name, value } = event.target

		setUser({ ...user, [name]: value })
	}

	let history = useHistory();
	const loginValid = () => {
		if (user.username && user.password === "Little-girl") {
			history.push("/mainform");
		}
		else {
			setUser(initialFormState);
		}
	}

	return (
		<form onSubmit={loginValid}>

			<div className="login-container">
				<div>
					<label>Username</label>
					<input type="text" name="username" className="textbox" value={user.username} onChange={handleInputChange} />
				</div>
				<div>
					<label>Password</label>
					<input type="password" name="password" className="textbox" value={user.password} onChange={handleInputChange} />
				</div>
				<button className="login-button">Login</button>

			</div>

		</form>


	)
}

export default LoginForm
