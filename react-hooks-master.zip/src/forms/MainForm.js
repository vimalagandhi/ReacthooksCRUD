import React, { useState, Fragment } from 'react'
import AddUserForm from './AddUserForm'
import EditUserForm from './EditUserForm'
import UserTable from '../tables/UserTable'

var archive = [];
const Mainform = () => {
		
	const allStorage = () => {
        for (var i = 0; i<localStorage.length; i++) {
            archive[i] = localStorage.getItem(localStorage.key(i));
		}
		console.log(archive)
		return archive;
	}
	allStorage();
	console.log("allstorage", allStorage())
	
	// Setting state
	const initialFormState = { id: null, name: '', username: '' }	
	const [users, setUsers] = useState(allStorage())
	const [currentUser, setCurrentUser] = useState(initialFormState)
	const [editing, setEditing] = useState(false)

	console.log("users", users)	

	// CRUD operations
	const addUser = user => {
		user.id = users.length + 1
		
		setUsers([...users, user])			
	}

	const deleteUser = id => {
		setEditing(false)

		setUsers(users.filter(user => user.id !== id))
		window.localStorage.removeItem(id);
	}

	const updateUser = (id, updatedUser) => {
		setEditing(false)

		setUsers(users.map(user => (user.id === id ? updatedUser : user)))
		window.localStorage.setItem(id, JSON.stringify({id: id, name: updatedUser.name, username: updatedUser.username}))
	}

	const editRow = user => {
		setEditing(true)

		setCurrentUser({ id: user.id, name: user.name, username: user.username })
	}
	
	return (
		<div className="container">
			<h1>CRUD App with Hooks</h1>
			<div className="flex-row">
				<div className="flex-large">
					{editing ? (
						<Fragment>
							<h2>Edit user</h2>
							<EditUserForm
								editing={editing}
								setEditing={setEditing}
								currentUser={currentUser}
								updateUser={updateUser}
							/>
						</Fragment>
					) : (
							<Fragment>
								<h2>Add user</h2>
								<AddUserForm addUser={addUser} />
							</Fragment>
						)}
				</div>
				<div className="flex-large">
					<h2>View users</h2>
					<UserTable users={users} editRow={editRow} deleteUser={deleteUser} />
				</div>
			</div>
		</div>
	)
}

export default Mainform
