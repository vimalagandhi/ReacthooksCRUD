import React from "react";
import { BrowserRouter as Router, Route, Redirect } from 'react-router-dom';
import Mainform from '../src/forms/MainForm'
import LoginForm from '../src/forms/LoginForm'

const App= () => {

   return (
      <div className="App">
         <Router>
            <div className="App-container">
               <Route path="/mainform" component={Mainform} />
               <Route path="/login" component={LoginForm} />
               <Redirect from='/'to="/login" />
            </div>
         </Router>

      </div>
   );

}

export default App;